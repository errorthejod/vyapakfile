import { Layout } from "@/components/Layout";
import { useStore } from "@/store/useStore";
import { SalesChart } from "@/components/SalesChart";
import { motion } from "framer-motion";
import { BarChart3, Users, ShoppingCart, TrendingUp } from "lucide-react";

const Reports = () => {
  const { invoices, parties } = useStore();
  const totalSale = invoices.filter(i => i.type === 'sale').reduce((sum, i) => sum + i.totalAmount, 0);
  const totalInvoices = invoices.length;
  const totalCustomers = parties.length;

  const partyWise = parties.map(p => {
    const partyInvoices = invoices.filter(i => i.partyId === p.id);
    const total = partyInvoices.reduce((sum, i) => sum + i.totalAmount, 0);
    return { name: p.name, total, count: partyInvoices.length };
  }).filter(p => p.total > 0).sort((a, b) => b.total - a.total);

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-heading font-bold text-foreground">Reports</h1>
          <p className="text-sm text-muted-foreground mt-1">Business analytics & insights</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { label: "Total Sales", value: `₹${totalSale.toLocaleString('en-IN')}`, icon: TrendingUp, color: "text-receivable", bg: "bg-receivable/10" },
            { label: "Total Invoices", value: totalInvoices, icon: ShoppingCart, color: "text-sale", bg: "bg-sale/10" },
            { label: "Total Customers", value: totalCustomers, icon: Users, color: "text-primary", bg: "bg-primary/10" },
          ].map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-card rounded-xl p-5 card-shadow"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className={`text-2xl font-bold font-heading mt-1 ${stat.color}`}>{stat.value}</p>
                </div>
                <div className={`h-11 w-11 rounded-xl flex items-center justify-center ${stat.bg}`}>
                  <stat.icon className={`h-5 w-5 ${stat.color}`} />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <SalesChart />

        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-card rounded-xl p-5 card-shadow"
        >
          <h3 className="font-heading font-semibold mb-4 flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            Party-wise Sales
          </h3>
          {partyWise.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">No sales data yet</p>
          ) : (
            <div className="space-y-3">
              {partyWise.map((p, i) => (
                <div key={i} className="flex items-center justify-between py-2 border-b last:border-0">
                  <div>
                    <p className="text-sm font-medium text-foreground">{p.name}</p>
                    <p className="text-xs text-muted-foreground">{p.count} invoice(s)</p>
                  </div>
                  <p className="text-sm font-semibold text-foreground">₹{p.total.toLocaleString('en-IN')}</p>
                </div>
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </Layout>
  );
};

export default Reports;
