import { useState, useRef } from "react";
import { Layout } from "@/components/Layout";
import { useStore } from "@/store/useStore";
import { InvoiceItem, Invoice } from "@/types";
import { InvoiceTemplate } from "@/components/InvoiceTemplate";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, FileText, Printer, Download, Eye } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";

const SuggestionInput = ({
  value,
  onChange,
  suggestions,
  placeholder,
}: {
  value: string;
  onChange: (val: string, selected?: { id?: string; phone?: string; address?: string; gst?: string }) => void;
  suggestions: { label: string; id?: string; phone?: string; address?: string; gst?: string }[];
  placeholder: string;
}) => {
  const [query, setQuery] = useState(value);
  const [show, setShow] = useState(false);
  const filtered = suggestions.filter((s) =>
    s.label.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="relative">
      <Input
        value={query}
        onChange={(e) => {
          setQuery(e.target.value);
          setShow(true);
          onChange(e.target.value);
        }}
        onFocus={(e) => {
          setShow(true);
          e.target.select();
        }}
        onBlur={() => setTimeout(() => setShow(false), 200)}
        placeholder={placeholder}
      />
      {show && query && filtered.length > 0 && (
        <div className="absolute z-50 top-full left-0 right-0 mt-1 bg-popover border border-border rounded-md shadow-lg max-h-40 overflow-auto">
          {filtered.map((s, idx) => (
            <button
              key={s.id || idx}
              className="w-full text-left px-3 py-2 text-sm hover:bg-accent hover:text-accent-foreground"
              onMouseDown={() => {
                setQuery(s.label);
                setShow(false);
                onChange(s.label, s);
              }}
            >
              {s.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

const ProductInput = ({
  value,
  onChange,
  items: productList,
}: {
  value: string;
  onChange: (name: string, itemId?: string, rate?: number, gstPercent?: number, unit?: string) => void;
  items: { id: string; name: string; price: number; gstPercent: number; unit: string }[];
}) => {
  const [query, setQuery] = useState(value);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const filtered = productList.filter((p) =>
    p.name.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="relative">
      <Input
        value={query}
        onChange={(e) => {
          setQuery(e.target.value);
          setShowSuggestions(true);
          onChange(e.target.value);
        }}
        onFocus={(e) => {
          setShowSuggestions(true);
          e.target.select();
        }}
        onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
        placeholder="Type product name"
      />
      {showSuggestions && query && filtered.length > 0 && (
        <div className="absolute z-50 top-full left-0 right-0 mt-1 bg-popover border border-border rounded-md shadow-lg max-h-40 overflow-auto">
          {filtered.map((item) => (
            <button
              key={item.id}
              className="w-full text-left px-3 py-2 text-sm hover:bg-accent hover:text-accent-foreground"
              onMouseDown={() => {
                setQuery(item.name);
                setShowSuggestions(false);
                onChange(item.name, item.id, item.price, item.gstPercent, item.unit);
              }}
            >
              {item.name} — ₹{item.price}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

const UNITS = ["Pcs", "Kg", "Ltr", "Mtr", "Box", "Pair", "Set", "Dozen"];
const TAX_OPTIONS = [
  { label: "None", value: 0 },
  { label: "GST 5%", value: 5 },
  { label: "GST 12%", value: 12 },
  { label: "GST 18%", value: 18 },
  { label: "GST 28%", value: 28 },
];

const Sales = () => {
  const { items, invoices, parties, addInvoice, addParty, shopInfo } = useStore();
  const [customerName, setCustomerName] = useState("");
  const [customerAddress, setCustomerAddress] = useState("");
  const [customerGst, setCustomerGst] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [invoiceDate, setInvoiceDate] = useState(new Date().toISOString().split("T")[0]);
  const [invoiceItems, setInvoiceItems] = useState<(InvoiceItem & { unit: string })[]>([]);
  const [showInvoice, setShowInvoice] = useState<Invoice | null>(null);
  const invoiceRef = useRef<HTMLDivElement>(null);

  const partySuggestions = parties
    .filter((p) => p.type === "customer")
    .map((p) => ({
      label: p.name,
      id: p.id,
      phone: p.phone,
      address: p.address,
      gst: p.gst || "",
    }));

  const addInvoiceItem = () => {
    setInvoiceItems([
      ...invoiceItems,
      { itemId: "", name: "", qty: 1, rate: 0, gstPercent: 18, amount: 0, cgst: 0, sgst: 0, unit: "Pcs" },
    ]);
  };

  const recalcItem = (item: InvoiceItem & { unit: string }) => {
    item.amount = item.qty * item.rate;
    const gstAmount = (item.amount * item.gstPercent) / 100;
    item.cgst = gstAmount / 2;
    item.sgst = gstAmount / 2;
    return item;
  };

  const updateInvoiceItem = (index: number, field: string, value: string | number) => {
    const updated = [...invoiceItems];
    updated[index] = recalcItem({ ...updated[index], [field]: value });
    setInvoiceItems(updated);
  };

  const handleProductChange = (
    index: number,
    name: string,
    itemId?: string,
    rate?: number,
    gstPercent?: number,
    unit?: string
  ) => {
    const updated = [...invoiceItems];
    const item = { ...updated[index], name };
    if (itemId) {
      item.itemId = itemId;
      item.rate = rate || 0;
      item.gstPercent = gstPercent || 18;
      item.unit = unit || "Pcs";
    }
    updated[index] = recalcItem(item);
    setInvoiceItems(updated);
  };

  const removeInvoiceItem = (index: number) => {
    setInvoiceItems(invoiceItems.filter((_, i) => i !== index));
  };

  const subtotal = invoiceItems.reduce((sum, i) => sum + i.amount, 0);
  const totalCgst = invoiceItems.reduce((sum, i) => sum + i.cgst, 0);
  const totalSgst = invoiceItems.reduce((sum, i) => sum + i.sgst, 0);
  const totalAmount = subtotal + totalCgst + totalSgst;

  const handleCustomerSelect = (
    val: string,
    selected?: { id?: string; phone?: string; address?: string; gst?: string }
  ) => {
    setCustomerName(val);
    if (selected?.address) setCustomerAddress(selected.address);
    if (selected?.gst) setCustomerGst(selected.gst);
    if (selected?.phone) setCustomerPhone(selected.phone);
  };

  const handleCreateInvoice = () => {
    if (!customerName.trim() || invoiceItems.length === 0) {
      toast.error("Enter customer name and add items");
      return;
    }

    // Auto-save new customer if not already in parties
    const existingParty = parties.find(
      (p) => p.name.toLowerCase() === customerName.trim().toLowerCase() && p.type === "customer"
    );
    if (!existingParty) {
      addParty({
        id: Date.now().toString(),
        name: customerName.trim(),
        phone: customerPhone.trim(),
        address: customerAddress.trim(),
        gst: customerGst.trim(),
        type: "customer",
        balance: 0,
        createdAt: new Date().toISOString(),
      });
    }

    const invoice: Invoice = {
      id: Date.now().toString(),
      invoiceNumber: `INV-${String(invoices.length + 1).padStart(3, "0")}`,
      date: invoiceDate,
      partyId: existingParty?.id || "",
      partyName: customerName.trim(),
      partyAddress: customerAddress.trim(),
      partyGst: customerGst.trim(),
      items: invoiceItems.map(({ unit, ...rest }) => rest),
      subtotal,
      totalCgst,
      totalSgst,
      totalAmount,
      type: "sale",
      createdAt: new Date().toISOString(),
    };

    addInvoice(invoice);
    setShowInvoice(invoice);
    setCustomerName("");
    setCustomerAddress("");
    setCustomerGst("");
    setCustomerPhone("");
    setInvoiceDate(new Date().toISOString().split("T")[0]);
    setInvoiceItems([]);
    toast.success("Invoice created!");
  };

  const handlePrint = () => window.print();

  const handleDownloadPDF = async () => {
    if (!invoiceRef.current) return;
    const canvas = await html2canvas(invoiceRef.current, { scale: 2, backgroundColor: "#ffffff" });
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF("p", "mm", "a4");
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
    pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
    pdf.save(`${showInvoice?.invoiceNumber || "invoice"}.pdf`);
    toast.success("PDF downloaded!");
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-heading font-bold text-foreground">Create Sale Invoice</h1>
          <p className="text-sm text-muted-foreground mt-1">Generate GST-compliant invoices</p>
        </div>

        <div className="bg-card rounded-xl p-6 card-shadow space-y-6">
          {/* Customer Details */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label>Customer Name *</Label>
              <SuggestionInput
                value={customerName}
                onChange={handleCustomerSelect}
                suggestions={partySuggestions}
                placeholder="Type customer name"
              />
            </div>
            <div>
              <Label>Phone</Label>
              <Input
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                placeholder="Phone number"
                onFocus={(e) => e.target.select()}
              />
            </div>
            <div>
              <Label>Address</Label>
              <Input
                value={customerAddress}
                onChange={(e) => setCustomerAddress(e.target.value)}
                placeholder="Customer address"
                onFocus={(e) => e.target.select()}
              />
            </div>
            <div>
              <Label>GST (Optional)</Label>
              <Input
                value={customerGst}
                onChange={(e) => setCustomerGst(e.target.value)}
                placeholder="GSTIN"
                onFocus={(e) => e.target.select()}
              />
            </div>
          </div>
          <div>
            <Label>Invoice Date</Label>
            <Input type="date" value={invoiceDate} onChange={(e) => setInvoiceDate(e.target.value)} />
          </div>

          {/* Items Table */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <Label className="text-base font-semibold">Items</Label>
              <Button variant="outline" size="sm" onClick={addInvoiceItem}>
                <Plus className="h-4 w-4 mr-1" />
                Add Item
              </Button>
            </div>

            {/* Table Header */}
            {invoiceItems.length > 0 && (
              <div className="grid grid-cols-12 gap-2 mb-2 px-1">
                <span className="col-span-3 text-xs font-semibold text-muted-foreground uppercase">Product</span>
                <span className="col-span-1 text-xs font-semibold text-muted-foreground uppercase">Qty</span>
                <span className="col-span-2 text-xs font-semibold text-muted-foreground uppercase">Unit</span>
                <span className="col-span-2 text-xs font-semibold text-muted-foreground uppercase">Price/Unit</span>
                <span className="col-span-2 text-xs font-semibold text-muted-foreground uppercase">Tax</span>
                <span className="col-span-1 text-xs font-semibold text-muted-foreground uppercase">Amount</span>
                <span className="col-span-1"></span>
              </div>
            )}

            <div className="space-y-2">
              {invoiceItems.map((invItem, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="grid grid-cols-12 gap-2 items-center"
                >
                  <div className="col-span-3">
                    <ProductInput
                      value={invItem.name}
                      onChange={(name, itemId, rate, gstPercent, unit) =>
                        handleProductChange(i, name, itemId, rate, gstPercent, unit)
                      }
                      items={items}
                    />
                  </div>
                  <div className="col-span-1">
                    <Input
                      type="number"
                      min={1}
                      value={invItem.qty}
                      onFocus={(e) => e.target.select()}
                      onChange={(e) => updateInvoiceItem(i, "qty", Number(e.target.value))}
                    />
                  </div>
                  <div className="col-span-2">
                    <Select
                      value={invItem.unit}
                      onValueChange={(v) => updateInvoiceItem(i, "unit", v)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {UNITS.map((u) => (
                          <SelectItem key={u} value={u}>
                            {u}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="col-span-2">
                    <Input
                      type="number"
                      value={invItem.rate}
                      onFocus={(e) => e.target.select()}
                      onChange={(e) => updateInvoiceItem(i, "rate", Number(e.target.value))}
                    />
                  </div>
                  <div className="col-span-2">
                    <Select
                      value={String(invItem.gstPercent)}
                      onValueChange={(v) => updateInvoiceItem(i, "gstPercent", Number(v))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {TAX_OPTIONS.map((t) => (
                          <SelectItem key={t.value} value={String(t.value)}>
                            {t.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="col-span-1">
                    <span className="text-sm font-medium block text-right">
                      ₹{(invItem.amount + invItem.cgst + invItem.sgst).toLocaleString("en-IN")}
                    </span>
                  </div>
                  <div className="col-span-1 flex justify-center">
                    <Button variant="ghost" size="icon" onClick={() => removeInvoiceItem(i)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </motion.div>
              ))}
              {invoiceItems.length === 0 && (
                <p className="text-center text-sm text-muted-foreground py-8">
                  Click "Add Item" to start billing
                </p>
              )}
            </div>
          </div>

          {/* Totals */}
          {invoiceItems.length > 0 && (
            <div className="flex justify-end">
              <div className="w-72 space-y-2 bg-secondary/50 rounded-lg p-4">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>₹{subtotal.toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">CGST</span>
                  <span>₹{totalCgst.toLocaleString("en-IN", { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">SGST</span>
                  <span>₹{totalSgst.toLocaleString("en-IN", { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between text-base font-bold border-t pt-2">
                  <span>Total</span>
                  <span className="text-primary">
                    ₹{totalAmount.toLocaleString("en-IN", { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>
            </div>
          )}

          <div className="flex gap-3">
            <Button onClick={handleCreateInvoice} className="flex-1">
              <FileText className="h-4 w-4 mr-2" />
              Create Invoice
            </Button>
          </div>
        </div>

        {/* Past Invoices */}
        <div className="bg-card rounded-xl p-5 card-shadow">
          <h3 className="font-heading font-semibold mb-4">Recent Invoices</h3>
          <div className="space-y-2">
            {invoices
              .filter((i) => i.type === "sale")
              .map((inv) => (
                <div key={inv.id} className="flex items-center justify-between py-3 border-b last:border-0">
                  <div>
                    <p className="text-sm font-medium">{inv.invoiceNumber}</p>
                    <p className="text-xs text-muted-foreground">
                      {inv.partyName} • {inv.date}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <p className="text-sm font-semibold">₹{inv.totalAmount.toLocaleString("en-IN")}</p>
                    <Button variant="ghost" size="icon" onClick={() => setShowInvoice(inv)}>
                      <Eye className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
          </div>
        </div>

        {/* Invoice Preview Dialog */}
        <Dialog open={!!showInvoice} onOpenChange={() => setShowInvoice(null)}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center justify-between">
                <span>Invoice Preview</span>
                <div className="flex gap-2 no-print">
                  <Button variant="outline" size="sm" onClick={handlePrint}>
                    <Printer className="h-4 w-4 mr-1" />
                    Print
                  </Button>
                  <Button size="sm" onClick={handleDownloadPDF}>
                    <Download className="h-4 w-4 mr-1" />
                    PDF
                  </Button>
                </div>
              </DialogTitle>
            </DialogHeader>
            {showInvoice && <InvoiceTemplate ref={invoiceRef} invoice={showInvoice} shopInfo={shopInfo} />}
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
};

export default Sales;
