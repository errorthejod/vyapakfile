import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { motion } from "framer-motion";

const data = [
  { month: "Apr", amount: 45000 },
  { month: "May", amount: 62000 },
  { month: "Jun", amount: 58000 },
  { month: "Jul", amount: 78000 },
  { month: "Aug", amount: 91000 },
  { month: "Sep", amount: 85000 },
  { month: "Oct", amount: 110000 },
  { month: "Nov", amount: 95000 },
  { month: "Dec", amount: 125000 },
  { month: "Jan", amount: 105000 },
  { month: "Feb", amount: 98000 },
  { month: "Mar", amount: 135000 },
];

export function SalesChart() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: 0.1 }}
      className="bg-card rounded-xl p-5 card-shadow"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-heading font-semibold text-foreground">Monthly Sales</h3>
        <span className="text-xs font-medium text-muted-foreground bg-secondary px-2.5 py-1 rounded-full">FY 2024-25</span>
      </div>
      <ResponsiveContainer width="100%" height={280}>
        <AreaChart data={data} margin={{ top: 5, right: 5, left: -15, bottom: 0 }}>
          <defs>
            <linearGradient id="salesGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="hsl(217, 91%, 50%)" stopOpacity={0.2} />
              <stop offset="100%" stopColor="hsl(217, 91%, 50%)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(220, 13%, 91%)" vertical={false} />
          <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'hsl(220, 10%, 46%)' }} />
          <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'hsl(220, 10%, 46%)' }} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
          <Tooltip
            contentStyle={{
              backgroundColor: 'hsl(0, 0%, 100%)',
              border: '1px solid hsl(220, 13%, 91%)',
              borderRadius: '8px',
              fontSize: '13px',
              boxShadow: '0 4px 12px hsl(220 30% 12% / 0.08)',
            }}
            formatter={(value: number) => [`₹${value.toLocaleString('en-IN')}`, 'Sales']}
          />
          <Area type="monotone" dataKey="amount" stroke="hsl(217, 91%, 50%)" strokeWidth={2.5} fill="url(#salesGradient)" />
        </AreaChart>
      </ResponsiveContainer>
    </motion.div>
  );
}
