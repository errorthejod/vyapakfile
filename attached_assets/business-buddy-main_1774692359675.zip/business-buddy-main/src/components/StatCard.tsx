import { motion } from "framer-motion";
import { LucideIcon } from "lucide-react";

interface StatCardProps {
  title: string;
  amount: number;
  icon: LucideIcon;
  colorClass: string;
  bgClass: string;
}

export function StatCard({ title, amount, icon: Icon, colorClass, bgClass }: StatCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="bg-card rounded-xl p-5 card-shadow hover:card-shadow-hover transition-shadow"
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground font-medium">{title}</p>
          <p className={`text-2xl font-bold font-heading mt-1 ${colorClass}`}>
            ₹{amount.toLocaleString('en-IN')}
          </p>
        </div>
        <div className={`h-11 w-11 rounded-xl flex items-center justify-center ${bgClass}`}>
          <Icon className={`h-5 w-5 ${colorClass}`} />
        </div>
      </div>
    </motion.div>
  );
}
